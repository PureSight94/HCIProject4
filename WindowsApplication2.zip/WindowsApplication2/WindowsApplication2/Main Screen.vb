﻿Public Class Form1
    Private Sub ToolbarGroupBox_Enter(sender As System.Object, e As System.EventArgs) Handles ToolbarGroupBox.Enter

    End Sub



End Class
